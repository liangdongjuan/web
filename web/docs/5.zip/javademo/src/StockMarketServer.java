package StockMarket;
import java.rmi.*;
import java.rmi.Naming;
import java.rmi.registry.*;


public class StockMarketServer {
    
   public static void main(String args[]) throws Exception{
    
        int port=0;
        try{
        if (args[0].length()>0) {
              Integer tempInt=new Integer(args[0]);
              port=tempInt.intValue();             
            }
        }
        catch(Exception e){
            
        }
        if (port>0){
            // Create LocalRegistry
            Registry reg;
            port=1099;
            try{
                java.rmi.registry.LocateRegistry.createRegistry(port);
            }
            catch(RemoteException e){
                System.out.println("Could not create Registry. port "+port+" may be in use");
            java.lang.Runtime.getRuntime().exit(1);
            }
        }
        else{
            port=1099;
        }
        
        String tempString=new String(new Integer(port).toString());
        ObjectFactoryImpl objectFactoryRef = new ObjectFactoryImpl();
        
        Naming.rebind("rmi://localhost:"+tempString+"/ObjectFactoryImpl", objectFactoryRef);
        System.out.println("[Server Instance]\r\n");
        System.out.println("StockMarket ObjectFactory Instantiated...@"+tempString);
   }
 }
