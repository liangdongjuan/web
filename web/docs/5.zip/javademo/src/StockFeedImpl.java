package StockMarket;
 
import java.io.*;
import java.io.InputStreamReader.*;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.Vector;

public class StockFeedImpl extends UnicastRemoteObject implements StockFeed {
 
    public StockFeedImpl() throws RemoteException{}
    public String refresh() throws RemoteException{
        String feed=new String();
        String marketFeed=new String();
        String[] fileList=new String[1000];
        
        File currentDir=new File("MarketData");
        fileList=currentDir.list();
        int counter=0;
        try{
            for (counter=0;counter<1000;counter++){
               try{ 
                    if (fileList[counter].equalsIgnoreCase("none")){
                        //insert debug code here 
                        }
                    else{
                         
                        BufferedReader inReader = new BufferedReader(new FileReader("MarketData//"+fileList[counter]+"//price.dat"));
                        String tempString=fileList[counter]+" ";
                        tempString=tempString+inReader.readLine(); 
                        tempString=tempString+"     ";
                        try{
                            BufferedReader marketReader = new BufferedReader(new FileReader("MarketData//"+fileList[counter]+"//container.dat"));
                            marketReader.close();
                            marketFeed=marketFeed+tempString;
                        }
                        catch(Exception e){
                            feed=feed+tempString;
                        }
                        inReader.close();
                    }

               }
               catch(Exception e){};
            }       
            
        }
        catch(Exception e){};
        return feed+marketFeed+"   "+feed+"   ";
    }
        
    public String[] getStockNames() throws RemoteException {
        Vector names=new Vector();
        String[] fileList=new String[1000];
        
        File currentDir=new File("MarketData");
        fileList=currentDir.list();
        int counter=0;
        try{
            for (counter=0;counter<1000;counter++){
               try{ 
                    if (fileList[counter].equalsIgnoreCase("none")){
                        //insert debug code here 
                        }
                    else{
                        try{
                           File nfile = new File("MarketData//"+fileList[counter]);
                           if (nfile.isDirectory()){
                             try{ 
                                File file = new File("MarketData//"+fileList[counter]+"//container.dat");
                                if (!file.exists()) names.addElement(fileList[counter]);
                                }catch(Exception e1){};
                           }
                        }
                        catch(Exception e){
                            
                        }
                    } 
               }
               catch(Exception e){};
            }       
            
        }
        catch(Exception e){};
        String[] FileListArray=new String[1000];
        names.copyInto(FileListArray);
        return (FileListArray);
    }
    
    public String[] getMarketNames() throws RemoteException {
        Vector names=new Vector();
        String[] fileList=new String[1000];
        
        File currentDir=new File("MarketData");
        fileList=currentDir.list();
        int counter=0;
               try{
            for (counter=0;counter<1000;counter++){
               try{ 
                    if (fileList[counter].equalsIgnoreCase("none")){
                        //insert debug code here 
                        }
                    else{
                        try{
                           File nfile = new File("MarketData//"+fileList[counter]);
                           if (nfile.isDirectory()){
                             try{ 
                                File file = new File("MarketData//"+fileList[counter]+"//container.dat");
                                if (file.exists()) names.addElement(fileList[counter]);
                                }catch(Exception e1){};
                           }
                        }
                        catch(Exception e){
                            
                        }
                    } 
               }
               catch(Exception e){};
            }   
            
        }
        catch(Exception e){};
        String[] FileListArray=new String[1000];
        names.copyInto(FileListArray);
        return (FileListArray);
        
    }
    public String[] getPortfolios() throws RemoteException{
        Vector names=new Vector();
        String[] fileList=new String[1000];
        
        File currentDir=new File("MarketData");
        fileList=currentDir.list();
        int counter=0;
               try{
            for (counter=0;counter<1000;counter++){
               try{ 
                    if (fileList[counter].equalsIgnoreCase("none")){
                        //insert debug code here 
                        }
                    else{
                        try{
                           File nfile = new File("MarketData//"+fileList[counter]);
                           if (!nfile.isDirectory()){
                              String tempString=fileList[counter];
                              if (tempString.startsWith("portfolio.")){
                                  int extractfrom=tempString.indexOf(".");
                                  extractfrom++;
                                  tempString=tempString.substring(extractfrom);
                                  names.addElement(tempString);
                              }
                                
                           }
                        }
                        catch(Exception e){
                            
                        }
                    } 
               }
               catch(Exception e){};
            }   
            
        }
        catch(Exception e){};
        String[] FileListArray=new String[1000];
        names.copyInto(FileListArray);
        return (FileListArray);
        
        
    }
}