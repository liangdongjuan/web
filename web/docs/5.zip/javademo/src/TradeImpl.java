package StockMarket;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

public class TradeImpl extends UnicastRemoteObject implements Trade {
    
    public TradeImpl(int session)throws RemoteException {
        this.IDSession=session;
    };
    public TradeImpl(int session, Stock stock) throws RemoteException {
        this.IDSession=session;
        this.setStock(stock);
    };
    
    public TradeImpl(int session, Stock stock, boolean buy) throws RemoteException {
        this.IDSession=session;
        this.setStock(stock);       
        this.Buy(buy);
    };
    
    public TradeImpl(int session, Stock stock, boolean buy, int quanity) throws RemoteException {
        this.IDSession=session;
        this.setStock(stock);       
        this.Buy(buy);
        this.setQuanity(quanity);
    };
    
    public TradeImpl(String[] tradeInfo)throws RemoteException{
        this.Item=new StockImpl(tradeInfo[0]);
        this.IDSession=new Integer(tradeInfo[1]).intValue();
        if (new Boolean(tradeInfo[2]).booleanValue()){
            Buy(true); 
            }
            else{
                Sell(true);
            }
            
        this.Quanity=new Integer(tradeInfo[3]).intValue();
       
    };
        
    public boolean isBuy() throws RemoteException{
        return this.BuyItem;
    };
    
    public boolean isSell() throws RemoteException{
        return !(this.BuyItem);
    };
    
    public Stock getStock() throws RemoteException{
        return this.Item;  
    };
    
    public int getQuanity() throws RemoteException{
        return this.Quanity;   
    };
   
    public float getTransactionPrice() throws RemoteException{
        return this.transactionPrice;  
    };
   
    public void Buy(boolean buy) throws RemoteException{
           this.BuyItem=buy;
    };
    
    public void Sell(boolean sell) throws RemoteException{
           this.BuyItem=!sell;
    };
    
    public void setStock(Stock stock) throws RemoteException{
           this.Item=stock;
    };
    
    public void setTransactionPrice(float transactionPrice) throws RemoteException{
           this.transactionPrice=transactionPrice;   
    }
    
    public void setQuanity(int quanity) throws RemoteException{
           this.Quanity=quanity;
    };
    public void Commit(float price, String MethodType, String Session)throws RemoteException{
           transactionPrice=price;
           System.out.print(Session);
           this.Commit();
    }
    public void Commit() throws RemoteException{
           if (BuyItem==true) {
            System.out.println("<===>"+this.hashCode()+":"+IDSession+"-> BuyOrder placed for "+Item.getName()+" at $"+transactionPrice+" in the amount of "+ Quanity+"<===>");
          }
          else
          {
            System.out.println("<===>"+this.hashCode()+":"+IDSession+"-> SellOrder placed for "+Item.getName()+" at $"+transactionPrice+" in the amount of "+ Quanity+"<===>");
          }
    };
    
    public String[] Confirm(String[] tradeInfo) throws RemoteException{
        
           //String[] tradeInfo=new String[5];
           tradeInfo[0]=(new Integer(IDSession)).toString();
           tradeInfo[1]=getStock().toString();  
           tradeInfo[2]=(new Long(System.currentTimeMillis())).toString();
           tradeInfo[3]=(new Boolean(BuyItem)).toString();
           tradeInfo[4]=(new Integer(getQuanity())).toString();
           return tradeInfo;
    }
    
    // Declare member objects
    private boolean BuyItem;
    private Stock Item;
    private int Quanity;
    private int IDSession;
    private float transactionPrice;
}