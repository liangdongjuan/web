package StockMarket;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

public class ObjectFactoryImpl extends UnicastRemoteObject implements ObjectFactory {

    
       public ObjectFactoryImpl() throws RemoteException {       
       };
       public Login Login(UserInfo userInfo) throws RemoteException {
            System.out.println("<=Creating Login remoteObject=>");
            LoginImpl loginRef = new LoginImpl(userInfo);
            return (Login) loginRef;
       };
       
       public Stock Stock(String name) throws RemoteException {
            System.out.println("<=Creating Stock remoteObject=>");
            StockImpl stockRef = new StockImpl(name);
            stockRef.refresh();
            return (Stock) stockRef;        
       };
       
       public Trade Trade(String[] tradeInfo) throws RemoteException {
            System.out.println("<=Creating Trade remoteObject=>");
            TradeImpl tradeRef = new TradeImpl(tradeInfo);        
            return (Trade) tradeRef;
       }     
       public StockFeed StockFeed() throws RemoteException {
            System.out.println("<=Creating StockFeed remoteObject=>");
            StockFeedImpl stockFeedRef = new StockFeedImpl();        
            return (StockFeed) stockFeedRef;
       };
       
       // Declare member objects
       private String UserName;
       private String Password;
}