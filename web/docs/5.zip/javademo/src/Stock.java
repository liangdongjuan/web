package StockMarket;
    import java.rmi.Remote;
    import java.rmi.RemoteException;
              
public interface Stock extends Remote{
 
    public String getName() throws RemoteException;
    public String getHistory() throws RemoteException;
    public String[] getNews() throws RemoteException;
    public String[] getDetails() throws RemoteException;
    public String[] getTable() throws RemoteException;
    public boolean isContainer() throws RemoteException;
    
    public float getPrice() throws RemoteException;
    public void setPrice(float price) throws RemoteException;
    
    public void setName(String name) throws RemoteException;
    public void setHistory(String history) throws RemoteException;
    public void setNews(String[] news) throws RemoteException;
    public void setDetails(String[] details) throws RemoteException;
    public void setTable(String[] chart) throws RemoteException;
    public void setContainer(boolean container) throws RemoteException;
      
    public void update() throws RemoteException;
    public void refresh() throws RemoteException;
    public void remove() throws RemoteException;
    
      
}