package StockMarket;

import java.io.*;
import java.io.InputStreamReader.*;
import java.util.Vector;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

public class LoginImpl extends UnicastRemoteObject implements Login {
      
       public LoginImpl(UserInfo userInfo) throws RemoteException {
            this.UserName=userInfo.UserName;
            this.Password=userInfo.Password;
            System.out.println("<B>User "+this.UserName+" is logged in using session "+this.hashCode()+"</B>");
        
       };
       public String getSession() throws RemoteException {
            
            String session=new String(new Integer(this.hashCode()).toString());
            return session;
       };
       
       public void setStockList(Vector StockList) throws RemoteException {
              String[] StockListArray=new String[1000];
              int counter=0;
              try{
                for (counter=0;counter<StockList.size();counter++){
                  StockListArray[counter]=(String) StockList.elementAt(counter);
                }
                StockListArray[counter+1]=null;
              }catch(Exception e){};
            
            StockListArray[counter+1]=null;
            System.out.println("<I>StockList posted by "+this.UserName+"</I>");
            
            try{
            DataOutputStream outStream = new DataOutputStream(new FileOutputStream("MarketData//portfolio."+this.UserName));
                for (counter=0;counter<1000;counter++){
                if (StockListArray[counter]==null) break;
                outStream.writeBytes(StockListArray[counter]); 
                outStream.writeBytes("\r\n");
                }
            outStream.close();    
            }
            catch(Exception e){
                 System.out.println("Error update profile for "+this.UserName);
            }                       
                       

      }
                        
      
       public Vector getStockList() throws RemoteException {
            Vector StockList=new Vector();
            int counter=0;
            String tempString="None";
            BufferedReader inReader=null;
            System.out.println("<I>StockList Requested by "+this.UserName+"</I>");
            try{
                inReader = new BufferedReader(new FileReader("MarketData//portfolio."+this.UserName));
            }
            catch (Exception e){
                System.out.println("<I>User "+this.UserName+" does not have a profile...Using Default");
            }
            try{
               if (inReader==null){
                inReader= new BufferedReader(new FileReader("MarketData//portfolio.default"));
               }
            }
            catch(Exception e){
                   System.out.println("Error reading Default StockList from database");    
            }
            
            try{
              for (counter=0;counter<1000;counter++){
                  tempString=inReader.readLine(); 
                  if (tempString!=null){
                        System.out.println("...."+tempString);
                        StockList.addElement(tempString); 
                    }
                    else{
                        break;
                    }
              }
            inReader.close();
            }
            catch(Exception e){
                System.out.println("Error reading StockList from database"); 
            System.exit(1) ;
            }
            return (StockList);
            
       };
       
    public void removeUser() throws RemoteException{
        System.out.println("deleting user profile for "+this.UserName);
        try{
            File file = new File("MarketData//portfolio."+this.UserName);
            file.delete();
        }
        catch(Exception e){
            System.out.println("!error deleting user profile for "+this.UserName);
            }
    }
       
       
     // Declare member objects
     private String UserName;
     private String Password;
    
}