package StockMarket;
    import java.rmi.Remote;
    import java.rmi.RemoteException;
           
public interface StockFeed extends Remote{
 
    public String refresh() throws RemoteException;
    public String[] getStockNames() throws RemoteException;
    public String[] getMarketNames() throws RemoteException;
    public String[] getPortfolios() throws RemoteException;
}
