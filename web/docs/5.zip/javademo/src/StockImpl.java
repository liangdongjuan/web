package StockMarket;

import java.io.*;
import java.io.InputStreamReader.*;
import java.util.Date;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import com.symantec.itools.javax.swing.models.StringListModel;

public class StockImpl extends UnicastRemoteObject implements Stock {
    
    public StockImpl(String name) throws RemoteException {
        if (name==null) name="none";
        Name=name;
    };
    
    public String getName() throws RemoteException{
        return this.Name;
    };
    
    public String getHistory() throws RemoteException{
        return this.History;
    };
    
    public String[] getNews() throws RemoteException{
        return this.News;
    };
   
    public float getPrice() throws RemoteException{
        return this.Price;   
    };
    
    public String[] getDetails() throws RemoteException{
        return this.Details; 
    }
    
    public String[] getTable() throws RemoteException{
        return this.TableData;               
    }
    public boolean isContainer() throws RemoteException{
        return this.Container;
    } 
   
    public void setTable(String[] tableData) throws RemoteException{
        this.TableData=tableData;
    }
        
    public void setPrice(float price) throws RemoteException{
        this.Price=price;
    };
    
    public void setName(String name) throws RemoteException{
        this.Name=name;    
    };
    
    public void setHistory(String history) throws RemoteException{
        this.History=history;
    };
   
    public void setNews(String[] news) throws RemoteException{
        this.News=news;
    };
    
    public void setDetails(String[] details) throws RemoteException{
        this.Details=details;   
    }
    
    public void setContainer(boolean container) throws RemoteException{
        this.Container=container;   
    }
    
    public void remove() throws RemoteException{
        System.out.println("<B>Remove Request received for "+Name+"</B>");
        String tempString;
           try{
            File file = new File("MarketData//"+Name+"//History.dat");
            file.delete();
        }
        catch(Exception e){}
           try{
            File file = new File("MarketData//"+Name+"//Table.dat");
            file.delete();
        }
        catch(Exception e){}
           try{
            File file = new File("MarketData//"+Name+"//News.dat");
            file.delete();
        }
        catch(Exception e){}
           try{
            File file = new File("MarketData//"+Name+"//Details.dat");
            file.delete();
        }
        catch(Exception e){}
        try{
            File file = new File("MarketData//"+Name+"//Price.dat");
            file.delete();
        }
        catch(Exception e){}
        
        try{
            File file = new File("MarketData//"+Name);
            file.delete();
        }
        catch(Exception e){}
        
        
    }
    
    public void update() throws RemoteException{
        System.out.println("<B>Update Request received for "+Name+"</B>");
        String tempString;
        
        //if stock has never been written to disk create directory for market data
        try{
            File file = new File("MarketData//"+Name);
            file.mkdir();
        }
        catch(Exception e){}
        
        int counter=1;
        try{
        DataOutputStream outStream = new DataOutputStream(new FileOutputStream( "MarketData//"+Name+"//news.dat"));
        for (counter=1;counter<50;counter++){
            if (News[counter]==null) break;
            outStream.writeBytes(News[counter]);
            outStream.writeBytes("\r\n");
            System.out.println("<I>Sending News to provider..."+News[counter]+"</I>");
            }
        outStream.close();    
        }
        catch(Exception e){
           System.out.println("Error writing "+Name+" news from database");   
        }
                
        try{
        DataOutputStream outStream = new DataOutputStream(new FileOutputStream( "MarketData//"+Name+"//details.dat"));
        for (counter=0;counter<50;counter++){
            if (Details[counter]==null) break;
            outStream.writeBytes(Details[counter]); 
            outStream.writeBytes("\r\n");
            System.out.println("<I>Sending Details to provider..."+Details[counter]+"</I>");
            }
        outStream.close();    
        }
        catch(Exception e){
           System.out.println("Error sending "+Name+" Details from database");   
        }
               
           
        try{
        DataOutputStream outStream = new DataOutputStream(new FileOutputStream( "MarketData//"+Name+"//table.dat"));
        for (counter=0;counter<500;counter++){
            if (TableData[counter]==null) break;
            outStream.writeBytes(TableData[counter]); 
            outStream.writeBytes("\r\n");
            System.out.println("<I>Sending Charting Table to provider..."+TableData[counter]+"</I>");
            }
        outStream.close();    
        }
        catch(Exception e){
            
        }
               
        try{
        DataOutputStream outStream = new DataOutputStream(new FileOutputStream( "MarketData//"+Name+"//history.dat"));
        outStream.writeBytes(History); 
        outStream.writeBytes("\r\n");
        outStream.close();
        }
        catch(Exception e){
           System.out.println("Error sending "+Name+" history from database");   
        }
        
        try{
        DataOutputStream outStream = new DataOutputStream(new FileOutputStream( "MarketData//"+Name+"//price.dat"));
        outStream.writeBytes(new Float(Price).toString()); 
        outStream.writeBytes("\r\n");
        outStream.close();
        }
        catch(Exception e){
           System.out.println("Error sending "+Name+" value from database");   
        }
        
        try{
            File file=new File( "MarketData//"+Name+"//container.dat");
            file.delete();
                
            if (this.Container==true){
                DataOutputStream outStream = new DataOutputStream(new FileOutputStream( "MarketData//"+Name+"//container.dat"));
                outStream.writeBytes("Container");
                outStream.writeBytes("\r\n");
                outStream.close();
            }
        }
        catch(Exception e){
            System.out.println("Error sending "+Name+" container info from database");   
        }
    };
    
    public void refresh() throws RemoteException{
        System.out.println("<B>Request received for "+Name+"</B>");
        String tempString;
        StringListModel NewsList = new StringListModel();
        StringListModel DetailsList = new StringListModel();
        StringListModel TableList= new StringListModel();
        NewsList.addElement(new Date().toString());
        int counter=1;
        try{
        BufferedReader inReader = new BufferedReader(new FileReader("MarketData//"+Name+"//news.dat"));
        for (counter=1;counter<50;counter++){
            tempString=inReader.readLine(); 
            if (tempString==null) break;
            NewsList.addElement(tempString);
            System.out.println("<I>Receiving News from provider..."+NewsList.getElementAt(counter)+"</I>");
            }
        inReader.close();    
        }
        catch(Exception e){
           System.out.println("Error reading "+Name+" news from database");   
        }
        News=(String[])NewsList.toArray();
        
        try{
        BufferedReader inReader = new BufferedReader(new FileReader("MarketData//"+Name+"//details.dat"));
        for (counter=0;counter<50;counter++){
            tempString=inReader.readLine(); 
            if (tempString==null) break;
            DetailsList.addElement(tempString);
            System.out.println("<I>Receiving Details from provider..."+DetailsList.getElementAt(counter)+"</I>");
            }
        inReader.close();    
        }
        catch(Exception e){
           System.out.println("Error reading "+Name+" Details from database");   
        }
        Details=(String[])DetailsList.toArray();
        
           
        try{
        BufferedReader inReader = new BufferedReader(new FileReader("MarketData//"+Name+"//table.dat"));
        for (counter=0;counter<500;counter++){
            tempString=inReader.readLine(); 
            if (tempString==null) break;
            TableList.addElement(tempString);
            System.out.println("<I>Receiving Charting Table from provider..."+TableList.getElementAt(counter)+"</I>");
            }
        inReader.close();    
        }
        catch(Exception e){
        }
        TableData=(String[])TableList.toArray();
        
        
        try{
        BufferedReader inReader = new BufferedReader(new FileReader("MarketData//"+Name+"//history.dat"));
        History=inReader.readLine(); 
        inReader.close();
        }
        catch(Exception e){
           System.out.println("Error reading "+Name+" history from database");   
        }
        
        try{
        BufferedReader inReader = new BufferedReader(new FileReader("MarketData//"+Name+"//price.dat"));
        tempString=inReader.readLine(); 
        Float tempFloat=new Float(tempString);
        Price=tempFloat.floatValue();
        inReader.close();
        }
        catch(Exception e){
           System.out.println("Error reading "+Name+" value from database");   
        }
        
        try{
        BufferedReader inReader = new BufferedReader(new FileReader("MarketData//"+Name+"//container.dat"));
        inReader.close();
            this.Container=true;
        }
        catch(Exception e){
            this.Container=false;
        }
        System.out.println("<B>Sending...."+Name+"</B>");
    };
    
    // Declare member objects
    private String Name;
    private String News[];
    private String Details[];
    private String TableData[];
    private String History;
    private float Price;
    private boolean Container;
 
}