package StockMarket;
    import java.rmi.Remote;
    import java.rmi.RemoteException;
    
public interface ObjectFactory extends Remote{
 
    public Login Login(UserInfo userInfo)throws RemoteException;
    public Stock Stock(String name)throws RemoteException;
    public Trade Trade(String[] tradeInfo) throws RemoteException;
    public StockFeed StockFeed() throws RemoteException;
          
}