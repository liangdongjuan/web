package StockMarket;

public class UserInfo implements java.io.Serializable
{
    public UserInfo(){
        
    }
    public UserInfo(String UserName, String Password, String ProviderURL, String SecondaryURL){
        this.UserName=UserName;
        this.Password=Password;
        this.ProviderURL=ProviderURL;
        this.SecondaryURL=SecondaryURL;
    }
    public String UserName;
    public String Password;
    public String ProviderURL;
    public String SecondaryURL;
}