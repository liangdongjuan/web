package com.mercury.winrunner.custom;
        
public interface WinRunnerEditSupport{
 
    public String getSelectedText();
    public String getText();
 }