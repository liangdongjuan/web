package StockMarket;
    import java.util.Vector;
    import java.rmi.Remote;
    import java.rmi.RemoteException;
    //import com.symantec.itools.javax.swing.models.StringListModel;
        
public interface Login extends Remote{
 
    public String getSession() throws RemoteException;
    public Vector getStockList() throws RemoteException;
    public void setStockList(Vector StockList) throws RemoteException;
    public void removeUser() throws RemoteException;
 }