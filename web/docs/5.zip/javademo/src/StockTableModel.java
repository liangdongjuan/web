package StockMarket;

import java.io.*;
import java.net.URL;
import java.math.*;
import java.util.Vector;
import java.util.StringTokenizer;

public class StockTableModel extends javax.swing.table.AbstractTableModel implements Serializable
{
    public int getRowCount(){
		return rowCount;
	}
       
	public int getColumnCount(){
		return colCount;
	}
	
    
	public String getColumnName(int column){
       return (String)headerVector.elementAt(column);
	}

    public Class getColumnClass(int columnIndex){
		return String.class;
	}

    public Object getValueAt(int row, int column){
	    return (((Vector)dataVector.elementAt(row)).elementAt(column));
    }

    
	public void setValueAt(Object aValue, int row, int column){
		((Vector)dataVector.elementAt(row)).setElementAt(aValue, column);
		fireTableCellUpdated(row,column);
	}
    
	public boolean isCellEditable(int rowIndex, int columnIndex){
	    return false;
	}

	
	public URL getItems(){
	   return dataURL;
	}

	
	public void setURLBasedItems(URL newItems){
		dataVector = new Vector();
		dataURL = newItems;
		if (dataURL != null){
		    try{
		        colCount = 0;
		        
		        InputStream inputStream = null;
		        InputStreamReader inputStreamReader = null;
		        BufferedReader input = null;
		        
		        try{
    		        inputStream = (InputStream)newItems.getContent();
    		        inputStreamReader = new InputStreamReader(inputStream);
                    input = new BufferedReader(inputStreamReader);
    	            
    	            {
                        String nextLine;
                        while((nextLine = input.readLine())!= null){
        		            StringTokenizer currentLine = new StringTokenizer(nextLine,delimiterString);
        		            Vector newRow = new Vector();
        		            while(currentLine.hasMoreTokens()){
        		                newRow.addElement(currentLine.nextToken());
        		                if (newRow.size() > numHeaders){
        		                    //pad headers if needed
        		                    headerVector.addElement(" ");
        		                    numHeaders++;
        		                }
        		            }
                            colCount = Math.max(newRow.size(),colCount);
                            dataVector.addElement(newRow);
        		        }
    	            }
    		        
    		        rowCount = dataVector.size();
                    
    		        // pad any short rows
    		        for (int i = 0; i < dataVector.size();i++){
    		            Vector padVector = (Vector)dataVector.elementAt(i);
    		            
    		            int difference = colCount - padVector.size();
    		            if (difference > 0){
                            for (int j = 0; j< difference; j++)
                                padVector.addElement("");
    		            }
    		        }
		        }
		        finally{
		            if (input != null)
		                input.close();
		            else if (inputStreamReader != null)
		                inputStreamReader.close();
		            else if (inputStream != null)
		                inputStream.close();
		        }
	        }
		    catch (java.io.IOException e){
                e.printStackTrace(System.err);
		    }
		    catch (ClassCastException e){
		        // This seems to occur when the file does not exist
                Vector emptyRow = new Vector(colCount);
                for(int i = 0; i < Math.max(colCount,numHeaders);i++)
                    emptyRow.addElement("");
                dataVector.addElement(emptyRow);
		    }
        }
        else{
            Vector emptyRow = new Vector(colCount);
            for(int i = 0; i < Math.max(colCount,numHeaders);i++)
                emptyRow.addElement("");
            dataVector.addElement(emptyRow);
        }
        
        fireTableStructureChanged();
        fireTableDataChanged();
	}

public void setItems(String[] newItems)
	{
		dataVector = new Vector();
		
		int counter=0;
		int maxEntries=49;
		try{
		    //copy and validate the array into protected array object.
		    for (counter=0;counter<500;counter++){
		        if (newItems[counter]!=null){
		        dataObjects[counter] = newItems[counter];
		        }
		        else {
		            dataObjects[counter]=null;
		            break;
		        }
		    }
		}catch(java.lang.ArrayIndexOutOfBoundsException e){
		     maxEntries=counter;
		}
		
		if (dataObjects != null){
		    
		        colCount = 0;
		        String input = null;
		        
		        try{
    		      
    	            {
                        String nextLine;
                        counter=0;
                        while(counter<maxEntries){
                            nextLine = dataObjects[counter];
                            StringTokenizer currentLine = new StringTokenizer(nextLine,delimiterString);
        		            Vector newRow = new Vector();
        		            while(currentLine.hasMoreTokens()){
        		                newRow.addElement(currentLine.nextToken());
        		                if (newRow.size() > numHeaders){
        		                    //pad headers if needed
        		                    headerVector.addElement(" ");
        		                    numHeaders++;
        		                    
        		                }
        		            }
                            colCount = Math.max(newRow.size(),colCount);
                            dataVector.addElement(newRow);
                            counter++;
                           
                            if (counter>49) break;
        		        }
    	            }
    		        
    		        rowCount = dataVector.size();
                    
    		        // pad any short rows
    		        for (int i = 0; i < dataVector.size();i++){
    		            Vector padVector = (Vector)dataVector.elementAt(i);
    		            
    		            int difference = colCount - padVector.size();
    		            if (difference > 0){
                            for (int j = 0; j< difference; j++)
                                padVector.addElement("");
    		            }
    		        }
		        }
		   	    
		    catch (ClassCastException e){
		        // This seems to occur when the data does no exist
                Vector emptyRow = new Vector(colCount);
                for(int i = 0; i < Math.max(colCount,numHeaders);i++)
                    emptyRow.addElement("");
                dataVector.addElement(emptyRow);
		    }
		    catch (Exception e){
                e.printStackTrace(System.err);
		    }
        }
        else{
            Vector emptyRow = new Vector(colCount);
            for(int i = 0; i < Math.max(colCount,numHeaders);i++)
                emptyRow.addElement("");
            dataVector.addElement(emptyRow);
        }
        
        fireTableStructureChanged();
        fireTableDataChanged();
	}

	public String getColumnHeaders(){
        StringBuffer temp = new StringBuffer();
        for(int i = 0; i < headerVector.size();i++){
            if (temp.length() > 0){
                temp.append(",");
            }
            temp.append(headerVector.elementAt(i));
        }
    return temp.toString();
	}


	public void setColumnHeaders(String newHeaders){
        if (newHeaders == null)
		    newHeaders = "";

		StringTokenizer headers = new StringTokenizer(newHeaders,",");
	    headerVector = new Vector();
		numHeaders = headers.countTokens();

		for (int j = 0; j < Math.max(colCount,numHeaders);j++){
			if (headers.hasMoreTokens())
			    headerVector.addElement( headers.nextToken());
			else  // leave the space or the headers won't draw.
			    headerVector.addElement(" ");
		}

        fireTableStructureChanged();
        fireTableDataChanged();
	}

   public int getDelimiter(){
		return delimiter;
	}

   public void setDelimiter(int d)throws IllegalArgumentException{
		if(0 < d && d < (POSSIBLE_DELIMITERS+1))
			delimiter = d;
	    else
	        throw new IllegalArgumentException("delimiter must be between 1 and "+POSSIBLE_DELIMITERS+" inclusive");

		switch(delimiter){
			case TAB_DELIMITED: {delimiterString = "\t";break;}
			case COMMA_DELIMITED: {delimiterString = ",";break;}
			case SPACE_DELIMITED: {delimiterString = " ";break;}
			default : {delimiterString = "\t";break;}
		}
		setColumnHeaders(getColumnHeaders());
		setItems(this.dataObjects);
		fireTableStructureChanged();
		fireTableDataChanged();
	}


		//{{DECLARE_CONTROLS
		//}}
	//Declare member objects	
	public static final int TAB_DELIMITED = 1;
    public static final int COMMA_DELIMITED = 2;
    public static final int SPACE_DELIMITED = 3;
    protected static final int POSSIBLE_DELIMITERS = 3;
	protected int rowCount = 0;
	protected int colCount = 0;
	protected int numHeaders = 0;
    protected Vector dataVector = new Vector(rowCount);
	protected Vector headerVector = new Vector(colCount);
	protected URL dataURL;
    protected int delimiter = TAB_DELIMITED;
    protected String delimiterString = "\t";
    protected String[] dataObjects= new String[500];
}
