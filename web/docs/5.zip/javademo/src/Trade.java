package StockMarket;
    import java.rmi.Remote;
    import java.rmi.RemoteException;
    
public interface Trade extends Remote{
 
    public boolean isBuy() throws RemoteException;
    public boolean isSell() throws RemoteException;
    public Stock getStock() throws RemoteException;
    public int getQuanity() throws RemoteException;
    public float getTransactionPrice() throws RemoteException;
   
    public void Buy(boolean buy) throws RemoteException;
    public void Sell(boolean sell) throws RemoteException;
    public void setStock(Stock stock) throws RemoteException;
    public void setQuanity(int quanity) throws RemoteException;
    public void setTransactionPrice(float transactionPrice) throws RemoteException;
    
    public void Commit(float price, String MethodType, String Session) throws RemoteException;
    public void Commit() throws RemoteException;
    public String[] Confirm(String[] tradeInfo) throws RemoteException;
      
}